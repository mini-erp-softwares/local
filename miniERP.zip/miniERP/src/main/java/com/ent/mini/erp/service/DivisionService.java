package com.ent.mini.erp.service;

import java.util.List;

import com.ent.mini.erp.model.Division;

public interface DivisionService {


	Division save(Division division);

	Division update(Division division);

	List<Division> findAll();

	void delete(String id);

	List<Division> getDivision(String division);

}
