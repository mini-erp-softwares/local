package com.ent.mini.erp.service;

import java.util.List;

import com.ent.mini.erp.model.SalesOrganisation;

public interface SalesOrganisationService {

	SalesOrganisation save(SalesOrganisation plant);

	SalesOrganisation update(SalesOrganisation plant);

	List<SalesOrganisation> findAll();

	void delete(String id);

	List<SalesOrganisation> getSalesOrganisation(String salesOrganisation);

}
