package com.ent.mini.erp.service;

import java.util.List;

import com.ent.mini.erp.model.SerialProfile;

public interface SerialProfileService {

	SerialProfile save(SerialProfile plant);

	SerialProfile update(SerialProfile plant);

	List<SerialProfile> findAll();

	void delete(String id);

	List<SerialProfile> getSerialProfile(String serialProfile);
}
