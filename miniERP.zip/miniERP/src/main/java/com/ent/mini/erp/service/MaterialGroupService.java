package com.ent.mini.erp.service;

import java.util.List;

import com.ent.mini.erp.model.MaterialGroup;

public interface MaterialGroupService {

	MaterialGroup save(MaterialGroup plant);

	MaterialGroup update(MaterialGroup plant);

	List<MaterialGroup> findAll();

	void delete(String id);

	List<MaterialGroup> getMaterialGroup(String materialGroup);

}
