package com.ent.mini.erp.model;

public class ExceptionModel {

}
