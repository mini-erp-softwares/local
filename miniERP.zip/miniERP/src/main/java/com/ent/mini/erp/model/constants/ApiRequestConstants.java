package com.ent.mini.erp.model.constants;

public class ApiRequestConstants {

	public static final String ORIGIN_NAME = "ORIGIN_NAME";
	public static final String APPLICATION_NAME = "APPLICATION_NAME";
	public static final String PROCESS_NAME = "PROCESS_NAME";
	
}