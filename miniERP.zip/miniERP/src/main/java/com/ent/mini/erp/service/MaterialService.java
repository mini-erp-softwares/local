package com.ent.mini.erp.service;

import java.util.List;

import com.ent.mini.erp.model.MaterialMaster;

/**
 * Created by JavaDeveloperZone on 04-04-2018.
 */

public interface MaterialService {
    List<MaterialMaster> findAll();
    MaterialMaster save(MaterialMaster material);
    void delete(String materialId);
    MaterialMaster update(MaterialMaster material);
	List<MaterialMaster> getMaterial(String materialId);
}