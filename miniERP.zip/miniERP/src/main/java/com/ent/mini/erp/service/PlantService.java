package com.ent.mini.erp.service;

import java.util.List;

import com.ent.mini.erp.model.Plant;

public interface PlantService {

	Plant save(Plant plant);

	Plant update(Plant plant);

	List<Plant> findAll();

	void delete(String id);

	List<Plant> getPlant(String plant);

}
