package com.ent.mini.erp.service;

import java.util.List;

import com.ent.mini.erp.model.TemparatureCondition;

public interface TemparatureConditionService {

	TemparatureCondition save(TemparatureCondition plant);

	TemparatureCondition update(TemparatureCondition plant);

	List<TemparatureCondition> findAll();

	void delete(String id);

	List<TemparatureCondition> getTemparatureCondition(String temparatureCondition);

}
