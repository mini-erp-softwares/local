package com.ent.mini.erp.service;

import java.util.List;

import com.ent.mini.erp.model.CompanyCode;

/**
 * Created by MiniErp on 27-03-2020.
 */

public interface CompanyCodeService {
    List<CompanyCode> findAll();
    CompanyCode save(CompanyCode companyCode);
    void delete(String companyCodeId);
    CompanyCode update(CompanyCode companyCode);
	List<CompanyCode> getCompanyCode(String companyCodeId);
}