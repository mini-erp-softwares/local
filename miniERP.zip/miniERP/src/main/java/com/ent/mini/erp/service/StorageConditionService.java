package com.ent.mini.erp.service;

import java.util.List;

import com.ent.mini.erp.model.StorageCondition;

public interface StorageConditionService {

	StorageCondition update(StorageCondition plant);

	List<StorageCondition> findAll();

	StorageCondition save(StorageCondition plant);

	void delete(String id);

	List<StorageCondition> getStorageCondition(String storageCondition);

}
