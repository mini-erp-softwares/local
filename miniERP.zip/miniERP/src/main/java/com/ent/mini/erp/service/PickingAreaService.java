package com.ent.mini.erp.service;

import java.util.List;

import com.ent.mini.erp.model.PickingArea;

public interface PickingAreaService {

	PickingArea save(PickingArea plant);

	PickingArea update(PickingArea plant);

	List<PickingArea> findAll();

	void delete(String id);

	List<PickingArea> getPickingArea(String pickingArea);

}
